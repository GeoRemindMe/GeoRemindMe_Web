# -*- encoding: utf-8 -*-
# This file is distributed under the same license as the Django package.
#

DATE_FORMAT = 'd F Y'
TIME_FORMAT = 'H:i:s'
# DATETIME_FORMAT = 
# YEAR_MONTH_FORMAT = 
# MONTH_DAY_FORMAT = 
SHORT_DATE_FORMAT = 'd.n.Y'
# SHORT_DATETIME_FORMAT = 
# FIRST_DAY_OF_WEEK = 
# DATE_INPUT_FORMATS = 
# TIME_INPUT_FORMATS = 
# DATETIME_INPUT_FORMATS = 
DECIMAL_SEPARATOR = ','
THOUSAND_SEPARATOR = '.'
# NUMBER_GROUPING = 
